var bannerTranslateX = document.querySelector(".banner-translatex");
var bannerListTranslateX = bannerTranslateX.querySelector(".list");
var indicatorListTranslateX = bannerTranslateX.querySelector(".indicator");
var leftTranslatexBtn = bannerTranslateX.querySelector(".left");
var rightTranslatexBtn = bannerTranslateX.querySelector(".right");

var length = banners.length;
var preIndex = 0;
var curIndex = 0;

var timertranslatex = null;
var transformTime = 500;

var baseImgUrl = "https://res.vmallres.com";

// 创建元素
function createElTranslateX() {
  for (var i = 0; i < length; i++) {
    var banner = banners[i];
    bannerListTranslateX.innerHTML += ` 
    <li class="item">
      <a href="#">
        <img src="${baseImgUrl + banner.imgUrl}" alt="">
      </a>
    </li>`; 

    // 索引
    var li = document.createElement("li");
    if(i===0) {
      li.className = "active"; 
    } 
    li.index = i;
    indicatorListTranslateX.append(li);
    // 索引按钮
    li.onclick = function() {
      preIndex = curIndex;
      curIndex = this.index;
      moveTranslateX();
    }
  }
  cloneImg();
}
function cloneImg() {
  var first = bannerListTranslateX.children[0].cloneNode(true);
  var last = bannerListTranslateX.children[length-1].cloneNode(true);
  bannerListTranslateX.append(first);
  bannerListTranslateX.prepend(last);
  bannerListTranslateX.style.transform = "translateX(-100%)";
}

function moveTranslateX() {
  bannerListTranslateX.style.transform = `translateX(-${(curIndex+1)*100}%)`;
  bannerListTranslateX.style.transition = `transform ${transformTime}ms linear`;

  // console.log(preIndex, curIndex,curIndex===length);
  if (curIndex === length) {
    moveTranslateXTimer(1);
    curIndex = 0;
  }
  if(curIndex === -1 ) {
    moveTranslateXTimer(len);
    curIndex = length - 1;
  }

  indicatorListTranslateX.children[preIndex].classList.remove("active");
  indicatorListTranslateX.children[curIndex].classList.add("active");
}

function moveTranslateXTimer(num) {
  setTimeout(function() {
    bannerListTranslateX.style.transform = `translateX(-${num*100}%)`;
    bannerListTranslateX.style.transition = "none";
  },transformTime);
}
function startTimeTranslateX() {
  if (timertranslatex) return;
  timertranslatex = setInterval(function(){
    preIndex = curIndex;
    curIndex++;
    moveTranslateX();
  },
  3000);
}
function endTimeTranslateX() {
  if (!timertranslatex) return;
  clearInterval(timertranslatex);
  timertranslatex = null;
}



// 创建元素
createElTranslateX();

leftTranslatexBtn.onclick = function() {
  preIndex = curIndex;
  curIndex--;
  moveTranslateX();
}
rightTranslatexBtn.onclick = function() {
  preIndex = curIndex;
  curIndex++;
  moveTranslateX();
}
startTimeTranslateX();
bannerTranslateX.onmouseenter = function() {
  endTimeTranslateX();
}
bannerTranslateX.onmouseleave = function() {
  startTimeTranslateX();
}

document.onvisibilitychange = function() {
  // console.log(document.visibilityState);
  if (document.visibilityState === "visible") {
    startTime();
    startTimeTranslateX();
  } 
  if (document.visibilityState === "hidden") {
    endTime();
    endTimeTranslateX();
  }
}