var bannerOpacity = document.querySelector(".banner-opacity");
var bannerList = bannerOpacity.querySelector(".list");
var indicatorList = bannerOpacity.querySelector(".indicator");
var leftBtn = bannerOpacity.querySelector(".left");
var rightBtn = bannerOpacity.querySelector(".right");

var len = banners.length;
var prevoiusIndex = 0;
var currentIndex = 0;

var timer = null;

var baseImgUrl = "https://res.vmallres.com";

// 创建元素
function createEl() {
  for (var i = 0; i < len; i++) {
    var banner = banners[i];
    bannerList.innerHTML += ` 
    <li class="item">
      <a href="#">
        <img src="${baseImgUrl + banner.imgUrl}" alt="">
      </a>
    </li>`; 

    // 索引
    var li = document.createElement("li");
    if(i===0) {
      li.className = "active"; 
    } 
    li.index = i;
    indicatorList.append(li);
    // 索引按钮
    li.onclick = function() {
      prevoiusIndex = currentIndex;
      currentIndex = this.index;
      move();
    }
  }
}

function move() {
  // console.log(prevoiusIndex,currentIndex);

  if (currentIndex === len) {
    currentIndex = 0;
  }
  if(currentIndex === -1 ) {
    currentIndex = len - 1;
  }
  indicatorList.children[prevoiusIndex].classList.remove("active");
  indicatorList.children[currentIndex].classList.add("active");

  bannerList.children[prevoiusIndex].style.opacity = 0;
  bannerList.children[currentIndex].style.opacity = 1;
}

function startTime() {
  if (timer) return;
  timer = setInterval(function(){
    prevoiusIndex = currentIndex;
    currentIndex++;
    move();
  },
  3000);
}
function endTime() {
  if (!timer) return;
  clearInterval(timer);
  timer = null;
}

createEl();
leftBtn.onclick = function() {
  prevoiusIndex = currentIndex;
  currentIndex--;
  move();
}
rightBtn.onclick = function() {
  prevoiusIndex = currentIndex;
  currentIndex++;
  move();
}
startTime();
bannerOpacity.onmouseenter = function() {
  // console.log("enter");
  endTime();
}
bannerOpacity.onmouseleave = function() {
  // console.log("leave");
  startTime();
}

