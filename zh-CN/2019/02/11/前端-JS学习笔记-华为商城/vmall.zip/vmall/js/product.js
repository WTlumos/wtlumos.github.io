var productEl = document.querySelector(".product");

var showList = [].concat(resultList);
var baseUrl = "https://res2.vmallres.com/pimages";

var operationEl = document.querySelector(".operation");
var typeEl = operationEl.querySelector(".type");
var services = operationEl.querySelector(".services");
var orderEl = operationEl.querySelector(".order");
var orderActiveEl  = orderEl.children[1];
var typeFilters = [];
var serviceFilters = [];

// 创建元素
function createEle1() {
  productEl.innerHTML = "";
  for (var i = 0; i < showList.length; i++) {
    const result = showList[i];
    
    // 创建元素
    var item = document.createElement("div");
    item.className = "item";
    productEl.append(item);

    // a链接
    var a = document.createElement("a");
    a.href = "#";
    item.append(a);

    // 元素中的图片
    var img = document.createElement("img");
    img.className = "album";
    img.src = baseUrl + result.photoPath +"800_800_"+ result.photoName;
    a.append(img);

    // 标题
    var title = document.createElement("p");
    title.className = "title oneline";
    title.innerText = result.name;
    a.append(title);

    // 折扣
    var discount = document.createElement("p");
    discount.className = "discount online";
    discount.innerText = result.promotionInfo;
    a.append(discount);

    // 价格
    var price = document.createElement("p");
    price.className = "price";
    price.innerHTML = "&yen;"+result.price;
    a.append(price);

    // 福利
    var welfare = document.createElement("div");
    welfare.className = "welfare";
    var services = result.promoLabels;
    for (const service of services) {
      var span = document.createElement("span");
      span.innerText = service;
      welfare.append(span);
    }
    a.append(welfare);

    // 评论
    var comment = document.createElement("div");
    comment.className = "comment";
    var span = document.createElement("span");
    span.innerText = result.rateCount + "人评论";
    comment.append(span);
    span = document.createElement("span");
    span.innerText = result.goodRate + "%好评";
    comment.append(span);
    a.append(comment);
  }
  addEmptySpace(4);
}
// 创建元素
function createEle2() {
  productEl.innerHTML = "";
  var str = "";
  for (var i = 0; i < showList.length; i++) {
    const result = showList[i];

    // 图片地址
    imgSrc =  baseUrl + result.photoPath +"800_800_"+ result.photoName;
    // 福利
    var services = result.promoLabels;
    var welfare = "";
    for (const service of services) {
      welfare += `<span>${service}</span>`;
    }

    // 拼接元素
    str += ` 
      <div class="item">
        <a href="#">
          <img src="${imgSrc}" class="album">
          <p class="title oneline">${result.name}</p>
          <p class="discount">${result.promotionInfo}</p>
          <p class="price">&yen;${result.price}</p>
          <div class="welfare">${welfare}</div>
          <div class="comment">
            <span>${result.rateCount}人评论</span>
            <span>${result.goodRate}%好评</span>
          </div>
        </a>
      </div>`;   
  }
  productEl.innerHTML = str;
  addEmptySpace(4); 
}
// 最后一行排布问题
function addEmptySpace(row) {
  for (var i = 0; i < row-2; i++) {
    var item = document.createElement("div");
    item.className = "item empty";
    productEl.append(item); 
  }
}

// 过滤条件
function filterArr() {
  showList = resultList.filter(function(item){
    var typeFlag = true;
    var serviceFlag = true;

    // 分类栏筛选
    for (var arr of typeFilters) {
      if (item.skuName.indexOf(arr) === -1) {
        typeFlag = false;
        break;
      }
    }
    if(typeFlag) {
      // 服务优惠栏筛选
      for (var arr of serviceFilters) {
        if(!item.services.includes(arr)) {
          serviceFlag = false;
          break;
        }
      }
    }
    return typeFlag&&serviceFlag;
  })
  createEle2();
  // console.log(showList,typeFilters,serviceFilters);
}

// 点击事件
function clickChoose(event,filters) {
  var item = event.target;
  var value = item.innerHTML;
  if(item === this.children[0]) return;
  if(item.classList.contains("active")) {
    var idx = filters.indexOf(value);
    filters.splice(idx,1);
    item.classList.remove("active");
  }
  else {
    filters.push(value);
    item.classList.add("active");
  }
  filterArr();
}

// 创建元素
// createEle1();
createEle2();

typeEl.onclick = function(event) {
  clickChoose.apply(this,[event,typeFilters]);
}
services.onclick = function(event) {
  clickChoose.apply(this,[event,serviceFilters]);
}
orderEl.onclick = function(event) {
  var item = event.target;
  if(item === this.children[0]) return;
  orderActiveEl.classList.remove("active");
  item.classList.add("active");
  orderActiveEl = item;
  var key = item.dataset.key;
  // console.log(key)
  if(key === "default") {
    filterArr();
  } 
  else {
    showList = showList.sort(function(item1,item2) {
      return item2[key] - item1[key];
    });
    createEle2();
  }
}