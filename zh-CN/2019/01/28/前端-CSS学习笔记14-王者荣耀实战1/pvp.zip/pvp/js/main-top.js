// main-top 部分 图片列表
const photos = document.querySelector(".main-top .photos");
// 图片数组长度
const len = photos.children.length;
// 按钮数组
const btns = document.querySelectorAll(".main-top .btns a");
// 中间部分 - 导航栏
const navs = document.querySelectorAll(".main-top .nav .item");
// 中间部分 - 内容列表
const news = document.querySelector(".main-top .news");
// 图片索引 代表当前是第几张图片  0代表第一张图片
let count = 0;
let timer = null;

// 克隆第一张图片
let clonefirstImg = photos.children[0].cloneNode(true);
// 将第一张图片添加至图片列表的末尾
photos.append(clonefirstImg);

function move(){
  count++;
  photos.style.transform = `translate(-${count*100}%)`;
  // 为什么要加过渡? 因为切换到了最后一张假图时会将过渡去掉
  photos.style.transition = "transform 0.5s linear";
  // // 到达最后一张后无动画回到第一张
  if(count==len){
    count=0;
    setTimeout(()=>{
      // 取消过渡 500毫秒之后切换第一张
      photos.style.transform = "translateX(0)";
      photos.style.transition = "none";
    },500);
  }
}

// 底部对应信息鼠标进入事件
for (let i = 0; i < len; i++) {
  btns[i].addEventListener("mouseenter",()=>{
    count = i;
    setActive(btns,len,i);
    photos.style.transform = `translate(-${count*100}%)`;
    photos.style.transition = "none";
  });
}


// 自动轮播
timer = setInterval(()=>{
  move();
  setActive(btns,len,count);
},2000);

// 鼠标在图片上时定时器停止
photos.parentElement.addEventListener("mouseenter",()=>{
  // console.log("enter");
  clearInterval(timer);
  timer = null;
});
// 鼠标不在图片上时定时器重启
photos.parentElement.addEventListener("mouseleave",()=>{
  // console.log("leave");
  timer = setInterval(()=>{
    move();
    setActive(btns,len,count);
  },2000);
});

// 中间导航栏互斥
changeTranslateX(navs,navs.length,news,true);