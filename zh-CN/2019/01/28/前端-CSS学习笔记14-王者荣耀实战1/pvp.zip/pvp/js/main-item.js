// 内容中心导航栏
const contentNavs = document.querySelectorAll(".content-center .item_nav .item");
// 内容中心内容列表
const contentList = document.querySelector(".content-center .content-list");

// 内容中心每个内容中的小标题
// 精品栏目
const contentGreatSubNavs = contentList.querySelectorAll(".great-part .caption .item");
const contentGreatContentList = contentList.querySelector(".great-part .sub-content-list");

// 赛事精品
const contentGameSubNavs = contentList.querySelectorAll(".game-part .caption .item");
const contentGameContentList = contentList.querySelector(".game-part .sub-content-list");

// 英雄攻略
const contentHeroSubNavs = contentList.querySelectorAll(".hero-part .hero-type .item");
const contentHeroContentList = contentList.querySelector(".hero-part .hero-list");

// 赛事中心导航
const matchNavs = document.querySelectorAll(".match-center .item_nav .item");
const matchList = document.querySelector(".match-center .match-content");

// 英雄/皮肤导航栏
const heroSkinNavs = document.querySelectorAll(".hero-skin .item_nav .item");
// 英雄/皮肤内容列表
const heroSkinContent = document.querySelector(".hero-skin .hero-content");


// 内容中心导航内容移动
changeOpcaity(contentNavs,contentNavs.length,contentList);
// 内容中心子导航
// 精品推荐
changeTranslateX(contentGreatSubNavs,contentGreatSubNavs.length,contentGreatContentList);
// 赛事精品
changeTranslateX(contentGameSubNavs,contentGameSubNavs.length,contentGameContentList);
// 英雄推荐
changeTranslateY(contentHeroSubNavs,contentHeroSubNavs.length,contentHeroContentList);

// 赛事中心
changeOpcaity(matchNavs,matchNavs.length,matchList);

// 英雄/皮肤导航内容移动
changeTranslateX(heroSkinNavs,heroSkinNavs.length,heroSkinContent,true);