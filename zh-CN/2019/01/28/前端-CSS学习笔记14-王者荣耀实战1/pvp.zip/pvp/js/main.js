// 导航栏互斥-只能有一个元素有active类
function setActive(navs, len, num) {
  for (let i = 0; i < len; i++) {
    if(i==num){
      navs[i].classList.add("active");
    }
    else {
      navs[i].classList.remove("active");
    }  
  }
}

// 导航栏鼠标悬停-内容转变-向左
function changeTranslateX(navs, len, list, flag){
  // console.log(navs,len,list);
  for (let i = 0; i < len; i++) {
    navs[i].addEventListener("mouseenter",()=>{
      setActive(navs,len,i);
      list.style.transform = `translateX(-${i*100}%)`;
      if(flag) {
        list.style.transition = "transform 0.5s linear";
      }
    });
  }
}
// 向上
function changeTranslateY(navs, len, list, flag){
  for (let i = 0; i < len; i++) {
    navs[i].addEventListener("mouseenter",()=>{
      setActive(navs,len,i);
      list.style.transform = `translateY(-${i*100}%)`;
      if(flag) {
        list.style.transition = "transform 0.5s linear";
      }
    });
  }
}

function setOpacity(navs, len, num) {
  for (let i = 0; i < len; i++) {
    // console.log(navs[i]);
    navs[i].style.transition = "none";
    if(i==num){
      navs[i].style.opacity = 1;
      navs[i].style.transition = "opacity 0.6s linear";
    }
    else {
      navs[i].style.opacity = 0;
    }  
  }
}

// 导航栏鼠标悬停-内容透明度改变
function changeOpcaity(navs, len, list) {
  // console.log(navs,len,list);
  for (let i = 0; i < len; i++) {
    navs[i].addEventListener("mouseenter",()=>{
      setActive(navs,len,i);
      setOpacity(list.children,len,i);
      list.style.transform = `translateX(-${i*100}%)`;
    });
  }
}
