const closeBtn = document.querySelector(".down-flow .close");

closeBtn.addEventListener("click",function(e) {
  e.preventDefault();
  this.parentElement.style.display = "none";
});